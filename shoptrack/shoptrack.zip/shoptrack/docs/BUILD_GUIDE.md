# ShopTrack: step-by-step build and Git guide

From an empty folder to a project on GitHub. Commands are shown for Windows (PowerShell or Git Bash) and Mac/Linux where they differ.

---

## Part 1. File system design

```
shoptrack/                      <- parent folder (the Git repository)
├── .gitignore                  <- files Git must ignore (venv, database, secrets)
├── README.md                   <- how to run the project
├── requirements.txt            <- Python packages
├── pytest.ini                  <- test settings
├── run.py                      <- starts the app
├── app/
│   ├── __init__.py             <- creates the Flask app, registers blueprints
│   ├── config.py               <- settings (secret key, database path, shop name)
│   ├── db.py                   <- database connection + init-db / seed commands
│   ├── schema.sql              <- all 8 tables
│   ├── seed.py                 <- sample users and products for the demo
│   ├── auth.py                 <- login, logout, role checks            (Step 2)
│   ├── main.py                 <- home redirect + dashboard             (Steps 2, 7)
│   ├── users.py                <- admin manages users                   (Step 2)
│   ├── products.py             <- add, edit, delete, search, low stock  (Steps 3, 7)
│   ├── stock.py                <- receive deliveries                    (Step 4)
│   ├── sales.py                <- cart, complete sale, receipt, PDF     (Steps 5, 6)
│   ├── reports.py              <- totals, best sellers, CSV export      (Step 8)
│   ├── templates/              <- HTML pages (Jinja + Bootstrap)
│   │   ├── base.html           <- layout and navigation shared by all pages
│   │   ├── login.html
│   │   ├── dashboard.html
│   │   ├── receipt.html
│   │   ├── reports.html
│   │   ├── users.html
│   │   ├── products/  (list.html, form.html)
│   │   ├── stock/     (receive.html)
│   │   └── sales/     (new.html)
│   └── static/css/style.css
├── instance/                   <- shoptrack.db is created here (not committed)
├── tests/
│   └── test_sales.py
└── docs/
    ├── BUILD_GUIDE.md
    └── ShopTrack_Project_Pitch.pdf
```

Why this layout: one file per feature (blueprint), so teammates work on different files and rarely cause merge conflicts.

---

## Part 2. One-time setup (each team member)

1. Install **Python 3.10+** (tick "Add Python to PATH"), **Git**, and **VS Code**.
2. Create a free account at https://github.com.
3. Tell Git who you are:

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
git config --global init.defaultBranch main
```

Check: `python --version` and `git --version` both print a version.

---

## Part 3. Create the project (team lead does this once)

### Step A. Create the parent folder and open it

```bash
mkdir shoptrack
cd shoptrack
code .                  # opens VS Code here (optional)
```

### Step B. Create the folder structure

Mac/Linux/Git Bash:
```bash
mkdir -p app/templates/products app/templates/stock app/templates/sales app/static/css tests docs instance
```
PowerShell:
```powershell
mkdir app/templates/products, app/templates/stock, app/templates/sales, app/static/css, tests, docs, instance
```

### Step C. Create the virtual environment and install Flask

```bash
python -m venv venv
venv\Scripts\activate           # Windows PowerShell
source venv/bin/activate        # Mac/Linux/Git Bash
pip install Flask reportlab pytest
pip freeze > requirements.txt   # or use the requirements.txt provided
```

Your prompt now starts with `(venv)`. Always activate it before working.

### Step D. Initialise Git

```bash
git init
```

Create `.gitignore` **before the first commit** (use the one provided). It keeps `venv/`, `instance/*.db`, `.env` and `__pycache__/` out of GitHub.

### Step E. Create the repository on GitHub

Option 1, website: GitHub > **New repository** > name `shoptrack` > leave "Add README/.gitignore" **unticked** > **Create repository**.

Option 2, GitHub CLI: `gh repo create shoptrack --public`

### Step F. First commit and push

```bash
git add .gitignore README.md requirements.txt
git commit -m "Initial commit: README, requirements, gitignore"
git branch -M main
git remote add origin https://github.com/<your-username>/shoptrack.git
git push -u origin main
```

GitHub does not accept account passwords for pushes. A browser sign-in window (Git Credential Manager) opens on Windows, or use a Personal Access Token (GitHub > Settings > Developer settings > Tokens) as the password.

Check: refresh the repo page and you see your files.

### Step G. Add teammates

GitHub repo > **Settings > Collaborators > Add people**. Each teammate then runs:

```bash
git clone https://github.com/<your-username>/shoptrack.git
cd shoptrack
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

---

## Part 4. Teamwork rules (so nobody overwrites anyone)

```bash
git switch main && git pull                 # always start from the latest code
git switch -c feature/product-management    # one branch per step
# ...work, then:
git add .
git commit -m "Step 3: product management"
git push -u origin feature/product-management
```

Open a **Pull Request** on GitHub, a teammate reviews it, then **Merge**. Everyone then runs `git switch main && git pull`.

If you see a merge conflict, open the file, keep the correct lines, remove the `<<<<<<<` markers, then `git add` and `git commit`.

---

## Part 5. Build order, with the commit for each step

Finish each step fully before the next. Copy the files listed into your folder, run the check, then commit. `app/__init__.py` imports every blueprint, so while building, keep only the imports and `register_blueprint` entries for steps you have finished (the file marks each import with its step).

### Step 1. Setup and planning
Files: `app/__init__.py`, `app/config.py`, `app/db.py`, `app/schema.sql`, `run.py`
```bash
flask --app run init-db          # creates instance/shoptrack.db with all tables
git add . && git commit -m "Step 1: app factory, config and database schema"
git push
```
Check: `instance/shoptrack.db` exists.

### Step 2. Login and roles
Files: `auth.py`, `main.py` (index only for now), `users.py`, `seed.py`, `templates/base.html`, `login.html`, `users.html`
```bash
flask --app run seed
flask --app run run --debug
```
Check: log in as `jane.cashier` / `cashier123`; opening `/users/` shows a 403 error.
```bash
git add . && git commit -m "Step 2: login, roles and user management"
```

### Step 3. Product management
Files: `products.py`, `templates/products/list.html`, `form.html`
Check: as admin add a product, edit it, search it, delete it.
```bash
git add . && git commit -m "Step 3: product add, edit, delete and search"
```

### Step 4. Stock updates
Files: `stock.py`, `templates/stock/receive.html`
Check: receive 24 units of Sugar; Products shows the quantity rise by 24.
```bash
git add . && git commit -m "Step 4: receive stock from suppliers"
```

### Step 5. Sales screen (the heart of the project)
Files: `sales.py` (cart and complete routes), `templates/sales/new.html`
Check: add Sugar and Bread to the cart, click Complete sale, then see the stock drop.
```bash
git add . && git commit -m "Step 5: sales screen with cart and automatic stock deduction"
```

### Step 6. Receipts
Files: receipt routes in `sales.py`, `templates/receipt.html`
Check: the receipt opens after a sale; Print and Save PDF both work.
```bash
git add . && git commit -m "Step 6: printable and PDF receipts"
git tag core-complete
git push --tags
```
**Core complete: you now have a demo-ready project.**

### Step 7. Low-stock alerts
Files: `low_stock()` in `products.py`, `dashboard.html`, `main.py` dashboard route
Check: Milk (3 left) and Cooking oil (6 left) appear on the dashboard.
```bash
git add . && git commit -m "Step 7: dashboard and low-stock alerts"
```

### Step 8. Reports
Files: `reports.py`, `templates/reports.html`
Check: switch Today / This week / This month; download the CSV.
```bash
git add . && git commit -m "Step 8: sales reports and CSV export"
```

### Step 9. Testing and demo
Files: `tests/test_sales.py`, `pytest.ini`
```bash
python -m pytest
git add . && git commit -m "Step 9: automated tests"
git push
```
Rehearse the demo story: log in as cashier, add a product and receive stock (as manager), sell it, watch stock drop, print the receipt, open the report and low-stock alerts.

---

## Part 6. Daily Git routine (cheat sheet)

| Goal | Command |
|---|---|
| See what changed | `git status` |
| Get teammates' work | `git pull` |
| Save your work | `git add .` then `git commit -m "message"` |
| Upload it | `git push` |
| New branch | `git switch -c feature/name` |
| Undo edits to one file (not yet committed) | `git restore path/to/file` |
| See history | `git log --oneline` |

## Part 7. Troubleshooting

- **`flask` is not recognised**: the virtual environment is not active. Run the activate command again.
- **PowerShell blocks activate**: run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` once.
- **`ModuleNotFoundError: reportlab`**: run `pip install -r requirements.txt`.
- **Pushed `venv` or the database by mistake**: `git rm -r --cached venv instance/shoptrack.db`, commit, push.
- **Push rejected ("fetch first")**: run `git pull`, then `git push`.
- **Reset the demo data**: delete `instance/shoptrack.db`, then run `init-db` and `seed` again.

## Part 8. Optional extras (only after Step 6)

Sales chart with Chart.js, expiry tracking (the field already exists on products), M-Pesa through the Daraja API, a "Hold sale" button, an activity log table, and sales forecasting with pandas.

Before real use: set `SECRET_KEY` as an environment variable, change the seeded passwords, and run with a production server (for example `gunicorn`) rather than `--debug`.
