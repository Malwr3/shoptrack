import pytest

from app import create_app
from app.db import get_db, init_db
from app.seed import seed_db


@pytest.fixture
def app(tmp_path):
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / "test.db")})
    with app.app_context():
        init_db()
        seed_db()
    return app


def login(client, username, password):
    return client.post("/login", data={"username": username, "password": password})


def stock_of(app, sku):
    with app.app_context():
        return get_db().execute("SELECT quantity FROM products WHERE sku = ?", (sku,)).fetchone()[0]


def test_wrong_password_is_rejected(app):
    client = app.test_client()
    assert b"Wrong username or password" in login(client, "jane.cashier", "nope").data


def test_sale_deducts_stock(app):
    client = app.test_client()
    login(client, "jane.cashier", "cashier123")
    client.post("/sales/add/1")
    client.post("/sales/add/1")
    response = client.post("/sales/complete", data={"payment_method": "Cash", "amount_received": "500", "discount": "0"})
    assert response.status_code == 302 and "/receipts/" in response.headers["Location"]
    assert stock_of(app, "1001") == 40


def test_cash_short_payment_is_blocked(app):
    client = app.test_client()
    login(client, "jane.cashier", "cashier123")
    client.post("/sales/add/1")
    client.post("/sales/complete", data={"payment_method": "Cash", "amount_received": "10"})
    assert stock_of(app, "1001") == 42


def test_cannot_oversell(app):
    client = app.test_client()
    login(client, "jane.cashier", "cashier123")
    for _ in range(5):
        client.post("/sales/add/4")  # milk has only 3
    client.post("/sales/complete", data={"payment_method": "M-Pesa"})
    assert stock_of(app, "1004") == 0


def test_cashier_cannot_open_products(app):
    client = app.test_client()
    login(client, "jane.cashier", "cashier123")
    assert client.get("/products/").status_code == 403


def test_receive_stock_increases_quantity(app):
    client = app.test_client()
    login(client, "p.mwangi", "manager123")
    client.post("/stock/receive", data={"product_id": ["1"], "quantity": ["24"], "unit_cost": ["150"]})
    assert stock_of(app, "1001") == 66
