from werkzeug.security import generate_password_hash

from .db import get_db


def seed_db():
    db = get_db()
    with db:
        for username, name, pw, role in [
            ("amina.o", "Amina Otieno", "admin123", "admin"),
            ("p.mwangi", "Peter Mwangi", "manager123", "manager"),
            ("jane.cashier", "Jane Cashier", "cashier123", "cashier"),
        ]:
            db.execute(
                "INSERT OR IGNORE INTO users (username, full_name, password_hash, role) VALUES (?,?,?,?)",
                (username, name, generate_password_hash(pw), role),
            )
        for c in ("Groceries", "Drinks", "Household"):
            db.execute("INSERT OR IGNORE INTO categories (name) VALUES (?)", (c,))
        db.execute("INSERT OR IGNORE INTO suppliers (name, phone) VALUES ('Mumias Distributors', '0711 000 000')")

        cat = {r["name"]: r["id"] for r in db.execute("SELECT * FROM categories")}
        sup = db.execute("SELECT id FROM suppliers LIMIT 1").fetchone()["id"]
        # name, sku, category, buy, sell, qty, reorder
        for name, sku, c, buy, sell, qty, reorder in [
            ("Sugar 1kg", "1001", "Groceries", 150, 180, 42, 10),
            ("Cooking oil 1L", "1002", "Groceries", 260, 320, 6, 10),
            ("Bread", "1003", "Groceries", 55, 65, 25, 10),
            ("Milk 500ml", "1004", "Drinks", 50, 60, 3, 10),
            ("Soap bar", "1005", "Household", 70, 90, 60, 15),
        ]:
            db.execute(
                """INSERT OR IGNORE INTO products
                   (name, sku, category_id, supplier_id, buying_price, selling_price, quantity, reorder_level)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (name, sku, cat[c], sup, buy, sell, qty, reorder),
            )
