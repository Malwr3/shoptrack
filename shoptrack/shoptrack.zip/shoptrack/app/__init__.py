import os

from flask import Flask

from .config import Config


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)
    os.makedirs(os.path.dirname(app.config["DATABASE"]), exist_ok=True)

    from . import db
    db.init_app(app)

    # Register each blueprint as you build its step (see docs/BUILD_GUIDE.md)
    from . import auth, main          # Step 2
    from . import products            # Step 3
    from . import stock               # Step 4
    from . import sales               # Step 5 and 6 (receipts)
    from . import reports             # Step 8
    from . import users               # Step 2 (users screen)
    for module in (auth, main, products, stock, sales, reports, users):
        app.register_blueprint(module.bp)

    @app.template_filter("kes")
    def kes(value):
        value = float(value or 0)
        return f"{value:,.0f}" if value == int(value) else f"{value:,.2f}"

    return app
