import sqlite3

from flask import Blueprint, flash, redirect, render_template, request, url_for
from werkzeug.security import generate_password_hash

from .auth import roles_required
from .db import get_db

bp = Blueprint("users", __name__, url_prefix="/users")


@bp.route("/", methods=("GET", "POST"))
@roles_required("admin")
def index():
    db = get_db()
    if request.method == "POST":
        username = request.form["username"].strip()
        name = request.form["full_name"].strip()
        password = request.form["password"]
        role = request.form["role"]
        if not (username and name and len(password) >= 6) or role not in ("admin", "manager", "cashier"):
            flash("Fill in every field. The password needs at least 6 characters.", "danger")
        else:
            try:
                with db:
                    db.execute("INSERT INTO users (username, full_name, password_hash, role) VALUES (?,?,?,?)",
                               (username, name, generate_password_hash(password), role))
                flash("User added.", "success")
                return redirect(url_for("users.index"))
            except sqlite3.IntegrityError:
                flash("That username is taken.", "danger")
    return render_template("users.html", users=db.execute("SELECT * FROM users ORDER BY full_name").fetchall())
