from io import BytesIO

from flask import (Blueprint, current_app, flash, g, redirect, render_template,
                   request, send_file, session, url_for)
from reportlab.pdfgen import canvas

from .auth import login_required
from .db import get_db

bp = Blueprint("sales", __name__)
METHODS = ("Cash", "M-Pesa", "Card")


def num(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def cart_lines(db):
    lines = []
    for pid, qty in session.get("cart", {}).items():
        p = db.execute("SELECT * FROM products WHERE id = ? AND active = 1", (pid,)).fetchone()
        if p:
            lines.append({"product": p, "qty": qty, "total": p["selling_price"] * qty})
    return lines


def add_to_cart(db, product_id, change=1):
    p = db.execute("SELECT * FROM products WHERE id = ? AND active = 1", (product_id,)).fetchone()
    if p is None:
        return
    cart = session.get("cart", {})
    qty = cart.get(str(product_id), 0) + change
    if qty > p["quantity"]:
        flash(f"Only {p['quantity']} of {p['name']} in stock.", "warning")
        qty = p["quantity"]
    if qty <= 0:
        cart.pop(str(product_id), None)
    else:
        cart[str(product_id)] = qty
    session["cart"] = cart


@bp.route("/sales/new")
@login_required
def new():
    db = get_db()
    q = request.args.get("q", "").strip()
    category = request.args.get("category", type=int)
    if q:  # a barcode scanner types the SKU and presses Enter: add straight to cart
        hit = db.execute("SELECT id FROM products WHERE sku = ? AND active = 1", (q,)).fetchone()
        if hit:
            add_to_cart(db, hit["id"])
            return redirect(url_for("sales.new"))
    sql, params = "SELECT * FROM products WHERE active = 1", []
    if q:
        sql += " AND (name LIKE ? OR sku LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    if category:
        sql += " AND category_id = ?"
        params.append(category)
    products = db.execute(sql + " ORDER BY name LIMIT 24", params).fetchall()
    lines = cart_lines(db)
    return render_template("sales/new.html", products=products, lines=lines,
                           subtotal=sum(l["total"] for l in lines), q=q, category=category,
                           categories=db.execute("SELECT * FROM categories").fetchall())


@bp.post("/sales/add/<int:product_id>")
@login_required
def add(product_id):
    add_to_cart(get_db(), product_id)
    return redirect(url_for("sales.new"))


@bp.post("/sales/update/<int:product_id>")
@login_required
def update(product_id):
    action = request.form.get("action")
    if action == "remove":
        cart = session.get("cart", {})
        cart.pop(str(product_id), None)
        session["cart"] = cart
    else:
        add_to_cart(get_db(), product_id, 1 if action == "inc" else -1)
    return redirect(url_for("sales.new"))


@bp.post("/sales/clear")
@login_required
def clear():
    session.pop("cart", None)
    return redirect(url_for("sales.new"))


@bp.post("/sales/complete")
@login_required
def complete():
    db = get_db()
    lines = cart_lines(db)
    if not lines:
        flash("The cart is empty.", "warning")
        return redirect(url_for("sales.new"))

    subtotal = sum(l["total"] for l in lines)
    discount = min(max(num(request.form.get("discount")), 0), subtotal)
    total = subtotal - discount
    method = request.form.get("payment_method", "Cash")
    if method not in METHODS:
        method = "Cash"
    received = num(request.form.get("amount_received"), total)
    if method == "Cash" and received < total:
        flash(f"Amount received is less than the total (KES {total:,.0f}).", "danger")
        return redirect(url_for("sales.new"))
    if method != "Cash":
        received = total
    change = received - total

    try:
        with db:  # one transaction: sale + items + stock deduction, or nothing
            cur = db.execute(
                """INSERT INTO sales (user_id, subtotal, discount, total, payment_method,
                   amount_received, change_given) VALUES (?,?,?,?,?,?,?)""",
                (g.user["id"], subtotal, discount, total, method, received, change))
            sale_id = cur.lastrowid
            for l in lines:
                p, qty = l["product"], l["qty"]
                result = db.execute(
                    "UPDATE products SET quantity = quantity - ? WHERE id = ? AND quantity >= ?",
                    (qty, p["id"], qty))
                if result.rowcount == 0:
                    raise ValueError(f"Not enough stock for {p['name']}.")
                db.execute(
                    "INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, unit_cost) VALUES (?,?,?,?,?)",
                    (sale_id, p["id"], qty, p["selling_price"], p["buying_price"]))
    except ValueError as err:
        flash(str(err), "danger")
        return redirect(url_for("sales.new"))

    session.pop("cart", None)
    return redirect(url_for("sales.receipt", sale_id=sale_id))


def load_sale(sale_id):
    db = get_db()
    sale = db.execute("""SELECT s.*, u.full_name FROM sales s JOIN users u ON u.id = s.user_id
                         WHERE s.id = ?""", (sale_id,)).fetchone()
    items = db.execute("""SELECT si.*, p.name FROM sale_items si JOIN products p ON p.id = si.product_id
                          WHERE si.sale_id = ?""", (sale_id,)).fetchall()
    return sale, items


@bp.route("/receipts/<int:sale_id>")
@login_required
def receipt(sale_id):
    sale, items = load_sale(sale_id)
    if sale is None:
        return redirect(url_for("sales.new"))
    return render_template("receipt.html", sale=sale, items=items)


@bp.route("/receipts/<int:sale_id>/pdf")
@login_required
def receipt_pdf(sale_id):
    sale, items = load_sale(sale_id)
    if sale is None:
        return redirect(url_for("sales.new"))
    cfg = current_app.config
    width, height = 226, 190 + 14 * len(items)  # roughly 80mm till roll
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=(width, height))
    y = height - 20

    def row(left, right="", bold=False, centre=False):
        nonlocal y
        c.setFont("Courier-Bold" if bold else "Courier", 9)
        if centre:
            c.drawCentredString(width / 2, y, left)
        else:
            c.drawString(12, y, left)
            c.drawRightString(width - 12, y, right)
        y -= 13

    row(cfg["SHOP_NAME"].upper(), bold=True, centre=True)
    row(f"{cfg['SHOP_LOCATION']} - Tel {cfg['SHOP_PHONE']}", centre=True)
    row(f"Receipt #{sale['id']:04d}", sale["created_at"][:10])
    row(f"Cashier: {sale['full_name']}", sale["created_at"][11:16])
    y -= 4
    for i in items:
        row(f"{i['name'][:18]} x{i['quantity']}", f"{i['unit_price'] * i['quantity']:,.0f}")
    y -= 4
    row("Subtotal", f"{sale['subtotal']:,.0f}")
    row("Discount", f"{sale['discount']:,.0f}")
    row("TOTAL", f"{sale['total']:,.0f}", bold=True)
    row(sale["payment_method"], f"{sale['amount_received']:,.0f}")
    row("Change", f"{sale['change_given']:,.0f}")
    y -= 4
    row("Thank you. Come again.", centre=True)
    c.save()
    buf.seek(0)
    return send_file(buf, mimetype="application/pdf", download_name=f"receipt-{sale_id:04d}.pdf")
