from datetime import date

from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from .auth import roles_required
from .db import get_db

bp = Blueprint("stock", __name__, url_prefix="/stock")


@bp.route("/receive", methods=("GET", "POST"))
@roles_required("admin", "manager")
def receive():
    db = get_db()
    if request.method == "POST":
        lines = []
        try:
            for pid, qty, cost in zip(request.form.getlist("product_id"),
                                      request.form.getlist("quantity"),
                                      request.form.getlist("unit_cost")):
                if pid and qty:
                    if int(qty) > 0:
                        lines.append((int(pid), int(qty), float(cost or 0)))
        except ValueError:
            flash("Quantities and costs must be numbers.", "danger")
            lines = None
        if lines is not None and not lines:
            flash("Add at least one item.", "danger")
        elif lines:
            total = sum(q * c for _, q, c in lines)
            with db:  # one transaction: delivery + stock increase together
                cur = db.execute(
                    "INSERT INTO purchases (supplier_id, invoice_no, received_on, total_cost, user_id) VALUES (?,?,?,?,?)",
                    (request.form.get("supplier_id") or None, request.form.get("invoice_no", "").strip(),
                     request.form.get("received_on") or date.today().isoformat(), total, g.user["id"]))
                for pid, qty, cost in lines:
                    db.execute("INSERT INTO purchase_items (purchase_id, product_id, quantity, unit_cost) VALUES (?,?,?,?)",
                               (cur.lastrowid, pid, qty, cost))
                    db.execute("UPDATE products SET quantity = quantity + ?, "
                               "buying_price = CASE WHEN ? > 0 THEN ? ELSE buying_price END WHERE id = ?",
                               (qty, cost, cost, pid))
            flash(f"Delivery confirmed. {len(lines)} item(s) added to stock.", "success")
            return redirect(url_for("stock.receive"))
    return render_template("stock/receive.html", today=date.today().isoformat(),
                           suppliers=db.execute("SELECT * FROM suppliers").fetchall(),
                           products=db.execute("SELECT id, name, sku FROM products WHERE active=1 ORDER BY name").fetchall())
