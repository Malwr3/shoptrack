import sqlite3

from flask import Blueprint, flash, redirect, render_template, request, url_for

from .auth import roles_required
from .db import get_db

bp = Blueprint("products", __name__, url_prefix="/products")

BASE_SQL = """SELECT p.*, c.name AS category FROM products p
              LEFT JOIN categories c ON c.id = p.category_id WHERE p.active = 1"""


def low_stock(db):
    return db.execute(
        BASE_SQL + " AND p.quantity <= p.reorder_level ORDER BY p.quantity"
    ).fetchall()


@bp.route("/")
@roles_required("admin", "manager")
def index():
    db = get_db()
    q = request.args.get("q", "").strip()
    category = request.args.get("category", type=int)
    low = request.args.get("low")
    sql, params = BASE_SQL, []
    if q:
        sql += " AND (p.name LIKE ? OR p.sku LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    if category:
        sql += " AND p.category_id = ?"
        params.append(category)
    if low:
        sql += " AND p.quantity <= p.reorder_level"
    items = db.execute(sql + " ORDER BY p.name", params).fetchall()
    return render_template("products/list.html", items=items, q=q, category=category, low=low,
                           categories=db.execute("SELECT * FROM categories").fetchall(),
                           low_count=len(low_stock(db)))


def read_form():
    f = request.form
    try:
        data = {
            "name": f["name"].strip(),
            "sku": f["sku"].strip(),
            "category_id": f.get("category_id") or None,
            "supplier_id": f.get("supplier_id") or None,
            "buying_price": float(f["buying_price"] or 0),
            "selling_price": float(f["selling_price"] or 0),
            "quantity": int(f["quantity"] or 0),
            "reorder_level": int(f["reorder_level"] or 0),
            "expiry_date": f.get("expiry_date") or None,
        }
    except ValueError:
        return None, "Prices and quantities must be numbers."
    if not data["name"] or not data["sku"]:
        return None, "Name and SKU are required."
    if min(data["buying_price"], data["selling_price"], data["quantity"], data["reorder_level"]) < 0:
        return None, "Prices and quantities cannot be negative."
    return data, None


def form_context(db, product=None):
    return dict(product=product,
                categories=db.execute("SELECT * FROM categories").fetchall(),
                suppliers=db.execute("SELECT * FROM suppliers").fetchall())


@bp.route("/add", methods=("GET", "POST"))
@roles_required("admin", "manager")
def add():
    db = get_db()
    if request.method == "POST":
        data, error = read_form()
        if error is None:
            try:
                with db:
                    db.execute(
                        """INSERT INTO products (name, sku, category_id, supplier_id, buying_price,
                           selling_price, quantity, reorder_level, expiry_date)
                           VALUES (:name,:sku,:category_id,:supplier_id,:buying_price,
                           :selling_price,:quantity,:reorder_level,:expiry_date)""", data)
                flash("Product saved.", "success")
                return redirect(url_for("products.index"))
            except sqlite3.IntegrityError:
                error = "That SKU is already in use."
        flash(error, "danger")
    return render_template("products/form.html", **form_context(db))


@bp.route("/<int:product_id>/edit", methods=("GET", "POST"))
@roles_required("admin", "manager")
def edit(product_id):
    db = get_db()
    product = db.execute("SELECT * FROM products WHERE id = ? AND active = 1", (product_id,)).fetchone()
    if product is None:
        return redirect(url_for("products.index"))
    if request.method == "POST":
        data, error = read_form()
        if error is None:
            data["id"] = product_id
            try:
                with db:
                    db.execute(
                        """UPDATE products SET name=:name, sku=:sku, category_id=:category_id,
                           supplier_id=:supplier_id, buying_price=:buying_price,
                           selling_price=:selling_price, quantity=:quantity,
                           reorder_level=:reorder_level, expiry_date=:expiry_date WHERE id=:id""", data)
                flash("Changes saved.", "success")
                return redirect(url_for("products.index"))
            except sqlite3.IntegrityError:
                error = "That SKU is already in use."
        flash(error, "danger")
    return render_template("products/form.html", **form_context(db, product))


@bp.post("/<int:product_id>/delete")
@roles_required("admin")
def delete(product_id):
    # Soft delete: past sales keep pointing at the product
    with get_db() as db:
        db.execute("UPDATE products SET active = 0 WHERE id = ?", (product_id,))
    flash("Product deleted.", "success")
    return redirect(url_for("products.index"))
