import csv
from datetime import date, timedelta
from io import StringIO

from flask import Blueprint, Response, render_template, request

from .auth import roles_required
from .db import get_db

bp = Blueprint("reports", __name__, url_prefix="/reports")


def summary(db, start, end):
    """Totals for sales between two ISO dates (inclusive)."""
    s = db.execute("""SELECT COALESCE(SUM(total),0) AS total, COUNT(*) AS n,
                      COALESCE(SUM(discount),0) AS disc
                      FROM sales WHERE date(created_at) BETWEEN ? AND ?""", (start, end)).fetchone()
    i = db.execute("""SELECT COALESCE(SUM(si.quantity),0) AS units,
                      COALESCE(SUM((si.unit_price - si.unit_cost) * si.quantity),0) AS gross
                      FROM sale_items si JOIN sales s ON s.id = si.sale_id
                      WHERE date(s.created_at) BETWEEN ? AND ?""", (start, end)).fetchone()
    return {"total": s["total"], "count": s["n"], "units": i["units"], "profit": i["gross"] - s["disc"]}


def period_range(period, start, end):
    today = date.today()
    if period == "today":
        return today.isoformat(), today.isoformat()
    if period == "month":
        return today.replace(day=1).isoformat(), today.isoformat()
    if period == "custom" and start and end:
        return start, end
    return (today - timedelta(days=6)).isoformat(), today.isoformat()


def report_data(db, start, end):
    by_day = db.execute("""SELECT date(created_at) AS day, SUM(total) AS total FROM sales
                           WHERE date(created_at) BETWEEN ? AND ? GROUP BY day ORDER BY day""",
                        (start, end)).fetchall()
    best = db.execute("""SELECT p.name, SUM(si.quantity) AS units FROM sale_items si
                         JOIN sales s ON s.id = si.sale_id JOIN products p ON p.id = si.product_id
                         WHERE date(s.created_at) BETWEEN ? AND ?
                         GROUP BY p.id ORDER BY units DESC LIMIT 5""", (start, end)).fetchall()
    pay = db.execute("""SELECT payment_method, SUM(total) AS total FROM sales
                        WHERE date(created_at) BETWEEN ? AND ? GROUP BY payment_method""",
                     (start, end)).fetchall()
    stock_value = db.execute("SELECT COALESCE(SUM(quantity * buying_price),0) AS v FROM products WHERE active=1").fetchone()["v"]
    return by_day, best, pay, stock_value


@bp.route("/")
@roles_required("admin", "manager")
def index():
    db = get_db()
    period = request.args.get("period", "week")
    start, end = period_range(period, request.args.get("start"), request.args.get("end"))
    by_day, best, pay, stock_value = report_data(db, start, end)
    day_max = max([d["total"] for d in by_day], default=1) or 1
    best_max = max([b["units"] for b in best], default=1) or 1
    pay_total = sum(p["total"] for p in pay) or 1
    return render_template("reports.html", period=period, start=start, end=end,
                           s=summary(db, start, end), stock_value=stock_value,
                           by_day=by_day, day_max=day_max, best=best, best_max=best_max,
                           pay=pay, pay_total=pay_total)


@bp.route("/export.csv")
@roles_required("admin", "manager")
def export_csv():
    db = get_db()
    start, end = period_range(request.args.get("period", "week"), request.args.get("start"), request.args.get("end"))
    rows = db.execute("""SELECT s.id, s.created_at, u.full_name, s.payment_method, s.subtotal, s.discount, s.total
                         FROM sales s JOIN users u ON u.id = s.user_id
                         WHERE date(s.created_at) BETWEEN ? AND ? ORDER BY s.id""", (start, end)).fetchall()
    out = StringIO()
    writer = csv.writer(out)
    writer.writerow(["receipt", "date_time", "cashier", "payment", "subtotal", "discount", "total"])
    writer.writerows([tuple(r) for r in rows])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=sales_{start}_to_{end}.csv"})
