from flask import Blueprint, g, redirect, render_template

from .auth import home_for, login_required, roles_required
from .db import get_db
from .products import low_stock
from .reports import summary
from datetime import date

bp = Blueprint("main", __name__)


@bp.route("/")
@login_required
def index():
    return redirect(home_for(g.user))


@bp.route("/dashboard")
@roles_required("admin", "manager")
def dashboard():
    db = get_db()
    today = date.today().isoformat()
    recent = db.execute(
        """SELECT s.*, u.full_name,
                  (SELECT SUM(quantity) FROM sale_items WHERE sale_id = s.id) AS items
           FROM sales s JOIN users u ON u.id = s.user_id
           ORDER BY s.id DESC LIMIT 5"""
    ).fetchall()
    return render_template("dashboard.html", today=summary(db, today, today),
                           low=low_stock(db), recent=recent)
