import os

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-change-me")
    DATABASE = os.path.join(BASE_DIR, "instance", "shoptrack.db")
    SHOP_NAME = "Dukani Shop"
    SHOP_LOCATION = "Kisumu"
    SHOP_PHONE = "0700 000 000"
