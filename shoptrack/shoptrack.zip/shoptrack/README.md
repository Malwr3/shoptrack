# ShopTrack

A simple inventory and sales system for small shops (duka, pharmacy, hardware).
Built with Python, Flask and SQLite.

## Run it

```bash
python -m venv venv
venv\Scripts\activate          # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
flask --app run init-db
flask --app run seed
flask --app run run --debug
```

Open http://127.0.0.1:5000

| Role | Username | Password |
|---|---|---|
| Admin | amina.o | admin123 |
| Manager | p.mwangi | manager123 |
| Cashier | jane.cashier | cashier123 |

Change these passwords before using the system for real.

## Tests

```bash
python -m pytest
```

See `docs/BUILD_GUIDE.md` for the full step-by-step build and Git workflow.
